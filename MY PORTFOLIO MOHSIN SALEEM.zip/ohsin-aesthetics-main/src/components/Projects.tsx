import { motion } from "framer-motion";
import { ExternalLink, Github, Cpu, Pill } from "lucide-react";
import { Button } from "@/components/ui/button";

const Projects = () => {
  const projects = [
    {
      id: 1,
      title: "3D Model of Alternative Complement Pathway",
      description: "Led a team in creating a comprehensive 3D model of the Alternative Complement Pathway for UMT School of Pharmacy's microbiology competition. Under Prof. Hammad Ullah's guidance, our innovative presentation brought complex immunological processes to life through creative visualization.",
      icon: Pill,
      status: "1st Prize Winner 🏆",
      tech: ["3D Modeling", "Microbiology", "Immunology", "Team Leadership"],
      gradient: "from-primary to-primary-light",
      date: "June 21st",
      achievement: "First Prize - Faculty Praised Innovation"
    },
    {
      id: 2,
      title: "Different Dosage Forms Flow Chart",
      description: "Designed and developed a comprehensive paper chart showcasing various pharmaceutical dosage forms during 3rd semester. Led team collaboration under Prof. Muhammad Muaaz Munir's mentorship, demonstrating creativity in pharmacy education through visual design.",
      icon: Cpu,
      status: "1st Prize Winner 🏆",
      tech: ["Pharmaceutical Sciences", "Chart Design", "Dosage Forms", "Creative Design"],
      gradient: "from-secondary to-accent",
      date: "January 25th",
      achievement: "First Prize - 3rd Semester Excellence"
    },
    {
      id: 3,
      title: "AI Powered Pharmacy",
      description: "Developing an intelligent pharmacy management system that leverages machine learning for inventory optimization, drug interaction checking, and personalized medication recommendations.",
      icon: Pill,
      status: "In Development",
      tech: ["Python", "TensorFlow", "FastAPI", "React"],
      gradient: "from-primary to-primary-light",
    },
    {
      id: 4,
      title: "AI Powered Pharmaceutical Studies",
      description: "Research platform utilizing natural language processing and computer vision to analyze pharmaceutical literature and accelerate drug discovery processes.",
      icon: Cpu,
      status: "Research Phase",
      tech: ["Python", "PyTorch", "Hugging Face", "Streamlit"],
      gradient: "from-secondary to-accent",
    },
  ];

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-6xl mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-16">
            <motion.h2 
              className="text-4xl md:text-5xl font-bold text-gradient mb-4"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              Featured Projects
            </motion.h2>
            <motion.p 
              className="text-xl text-muted-foreground max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Innovative solutions at the intersection of pharmacy and artificial intelligence
            </motion.p>
          </div>

          {/* Projects Grid */}
          <div className="grid md:grid-cols-2 gap-8">
            {projects.map((project, index) => (
              <motion.div
                key={project.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="group"
              >
                <div className="glass rounded-2xl overflow-hidden hover-lift">
                  {/* Project Header with Gradient */}
                  <div className={`bg-gradient-to-r ${project.gradient} p-8 text-white relative overflow-hidden`}>
                    <motion.div
                      className="absolute inset-0 opacity-20"
                      animate={{ 
                        backgroundPosition: ["0% 0%", "100% 100%"] 
                      }}
                      transition={{ 
                        duration: 8, 
                        repeat: Infinity, 
                        repeatType: "reverse" 
                      }}
                      style={{
                        backgroundImage: "linear-gradient(45deg, transparent 30%, rgba(255,255,255,0.1) 50%, transparent 70%)",
                        backgroundSize: "200% 200%"
                      }}
                    />
                    
                    <div className="relative z-10 flex items-center justify-between">
                      <div className="flex items-center space-x-4">
                        <motion.div 
                          className="p-3 bg-white/20 rounded-xl"
                          whileHover={{ scale: 1.1, rotate: 5 }}
                          transition={{ duration: 0.3 }}
                        >
                          <project.icon className="w-8 h-8" />
                        </motion.div>
                        <div>
                          <h3 className="text-2xl font-bold">{project.title}</h3>
                          <span className="inline-block px-3 py-1 bg-white/20 rounded-full text-sm font-medium mt-2">
                            {project.status}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Project Content */}
                  <div className="p-8">
                    <p className="text-muted-foreground mb-6 leading-relaxed">
                      {project.description}
                    </p>

                    {/* Tech Stack */}
                    <div className="mb-6">
                      <h4 className="font-semibold text-foreground mb-3">Technologies</h4>
                      <div className="flex flex-wrap gap-2">
                        {project.tech.map((tech) => (
                          <span 
                            key={tech} 
                            className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-medium"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-3">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="hover-scale"
                        disabled
                      >
                        <Github className="w-4 h-4 mr-2" />
                        Coming Soon
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="hover-scale"
                        disabled
                      >
                        <ExternalLink className="w-4 h-4 mr-2" />
                        Preview
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Call to Action */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            viewport={{ once: true }}
            className="text-center mt-16"
          >
            <div className="glass p-8 rounded-2xl max-w-2xl mx-auto">
              <h3 className="text-2xl font-bold text-gradient mb-4">More Projects Coming Soon</h3>
              <p className="text-muted-foreground mb-6">
                I'm constantly working on new innovative solutions that combine pharmacy expertise with AI technology.
              </p>
              <Button 
                size="lg" 
                className="bg-gradient-primary hover:scale-105 transition-transform duration-300"
              >
                Follow My Journey
              </Button>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;