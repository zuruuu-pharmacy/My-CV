import { motion } from "framer-motion";
import { 
  Gamepad2, 
  Trophy, 
  Circle, 
  Search, 
  Tv, 
  Film,
  Heart,
  Star
} from "lucide-react";

const Hobbies = () => {
  const hobbies = [
    {
      icon: Trophy,
      name: "Cricket",
      description: "Strategic gameplay and team coordination",
      color: "from-green-400 to-green-600",
      emoji: "🏏"
    },
    {
      icon: Gamepad2,
      name: "Volleyball",
      description: "Team dynamics and quick reflexes",
      color: "from-orange-400 to-orange-600",
      emoji: "🏐"
    },
    {
      icon: Circle,
      name: "Football",
      description: "Passion for the beautiful game",
      color: "from-blue-400 to-blue-600",
      emoji: "⚽"
    },
    {
      icon: Search,
      name: "AI & Pharmacy Research",
      description: "Exploring cutting-edge innovations",
      color: "from-purple-400 to-purple-600",
      emoji: "🔬"
    },
    {
      icon: Tv,
      name: "Turkish Series",
      description: "Kurulus Usman & Sultan Al-Fateh",
      color: "from-red-400 to-red-600",
      emoji: "📺"
    },
    {
      icon: Film,
      name: "KGF Movies",
      description: "Epic storytelling and cinematography",
      color: "from-yellow-400 to-yellow-600",
      emoji: "🎬"
    },
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-6xl mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-16">
            <motion.h2 
              className="text-4xl md:text-5xl font-bold text-gradient mb-4"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              Hobbies & Interests
            </motion.h2>
            <motion.p 
              className="text-xl text-muted-foreground max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Beyond academics - the passions that fuel my creativity and balance
            </motion.p>
          </div>

          {/* Hobbies Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {hobbies.map((hobby, index) => (
              <motion.div
                key={hobby.name}
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ 
                  duration: 0.6, 
                  delay: index * 0.1,
                  type: "spring",
                  stiffness: 100 
                }}
                viewport={{ once: true }}
                className="group cursor-pointer"
              >
                <div className="glass rounded-2xl p-8 hover-lift text-center relative overflow-hidden">
                  {/* Background Animation */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-r ${hobby.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`}
                    initial={false}
                  />
                  
                  {/* Icon Container */}
                  <motion.div 
                    className={`w-20 h-20 mx-auto mb-6 rounded-2xl bg-gradient-to-r ${hobby.color} p-4 text-white relative`}
                    whileHover={{ 
                      scale: 1.1, 
                      rotate: [0, -5, 5, 0],
                      transition: { duration: 0.5 }
                    }}
                  >
                    <hobby.icon className="w-full h-full" />
                    
                    {/* Floating Emoji */}
                    <motion.div
                      className="absolute -top-2 -right-2 text-2xl"
                      animate={{ 
                        y: [-5, 5, -5],
                        rotate: [0, 10, -10, 0]
                      }}
                      transition={{ 
                        duration: 3,
                        repeat: Infinity,
                        ease: "easeInOut"
                      }}
                    >
                      {hobby.emoji}
                    </motion.div>
                  </motion.div>

                  {/* Content */}
                  <motion.div
                    initial={{ y: 10, opacity: 0 }}
                    whileInView={{ y: 0, opacity: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                    viewport={{ once: true }}
                  >
                    <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-primary transition-colors">
                      {hobby.name}
                    </h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {hobby.description}
                    </p>
                  </motion.div>

                  {/* Hover Effects */}
                  <motion.div
                    className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-primary to-secondary origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-300"
                  />
                </div>
              </motion.div>
            ))}
          </div>

          {/* Fun Quote */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            viewport={{ once: true }}
            className="text-center mt-16"
          >
            <div className="glass p-8 rounded-2xl max-w-3xl mx-auto relative">
              {/* Quote Marks */}
              <div className="absolute top-4 left-8 text-6xl text-primary/20 font-serif">"</div>
              <div className="absolute bottom-4 right-8 text-6xl text-primary/20 font-serif rotate-180">"</div>
              
              <motion.blockquote 
                className="text-xl text-muted-foreground italic leading-relaxed relative z-10"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ duration: 1, delay: 0.8 }}
                viewport={{ once: true }}
              >
                Life is about balance - whether it's between studies and sports, tradition and innovation, 
                or science and entertainment. Each passion teaches us something valuable.
              </motion.blockquote>
              
              <motion.div 
                className="flex items-center justify-center mt-6"
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, delay: 1 }}
                viewport={{ once: true }}
              >
                <Heart className="w-5 h-5 text-red-500 mr-2" />
                <span className="text-sm font-medium text-foreground">- Mohsin Saleem</span>
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hobbies;