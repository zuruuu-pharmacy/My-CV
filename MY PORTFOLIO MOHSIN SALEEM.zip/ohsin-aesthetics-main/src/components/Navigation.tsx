import { motion } from "framer-motion";
import { useState, useEffect } from "react";
import { Menu, X, User, Briefcase, MessageCircle, Target } from "lucide-react";
import { Button } from "@/components/ui/button";

const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("hero");
  const [isOnLightSection, setIsOnLightSection] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  const navItems = [
    { id: "hero", label: "Home", icon: Target },
    { id: "about", label: "About", icon: User },
    { id: "skills", label: "Skills", icon: Target },
    { id: "projects", label: "Projects", icon: Briefcase },
    { id: "contact", label: "Contact", icon: MessageCircle },
  ];

  useEffect(() => {
    const handleScroll = () => {
      const sections = navItems.map(item => item.id);
      const scrollPosition = window.scrollY + 100;

      for (const sectionId of sections) {
        const element = document.getElementById(sectionId);
        if (element) {
          const { offsetTop, offsetHeight } = element;
          if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
            setActiveSection(sectionId);
            // Determine if we're on a light background section
            const lightSections = ["about", "skills", "projects"];
            setIsOnLightSection(lightSections.includes(sectionId));
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    const checkTheme = () => {
      setIsDarkMode(document.documentElement.classList.contains('dark'));
    };
    
    checkTheme();
    
    // Watch for theme changes
    const observer = new MutationObserver(checkTheme);
    observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class'] });
    
    return () => observer.disconnect();
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
    setIsOpen(false);
  };

  return (
    <>
      {/* Desktop Navigation */}
      <motion.nav
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 1 }}
        className="fixed top-6 left-1/2 transform -translate-x-1/2 z-40 hidden md:block"
      >
        <div className="glass rounded-2xl px-6 py-3 border border-white/20 backdrop-blur-md">
          <ul className="flex space-x-1">
            {navItems.map((item) => (
              <li key={item.id}>
                <button
                  onClick={() => scrollToSection(item.id)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 ${
                    activeSection === item.id
                      ? `bg-white/20 ${
                          isDarkMode 
                            ? (isOnLightSection ? '!text-white' : '!text-gray-900')
                            : (isOnLightSection ? '!text-gray-900' : '!text-white')
                        }`
                      : `${
                          isDarkMode
                            ? (isOnLightSection ? '!text-white/70 hover:!text-white' : '!text-gray-700 hover:!text-gray-900')
                            : (isOnLightSection ? '!text-gray-700 hover:!text-gray-900' : '!text-white/70 hover:!text-white')
                        } hover:bg-white/10`
                  }`}
                >
                  {item.label}
                </button>
              </li>
            ))}
          </ul>
        </div>
      </motion.nav>

      {/* Mobile Navigation */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 1 }}
        className="fixed top-6 left-6 z-50 md:hidden"
      >
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsOpen(!isOpen)}
          className="glass border-white/20 hover:bg-white/10 backdrop-blur-md"
        >
          <motion.div
            key={isOpen ? "close" : "menu"}
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ duration: 0.3 }}
          >
            {isOpen ? (
              <X className="h-4 w-4 text-white" />
            ) : (
              <Menu className="h-4 w-4 text-white" />
            )}
          </motion.div>
        </Button>
      </motion.div>

      {/* Mobile Menu */}
      <motion.div
        initial={{ opacity: 0, x: -300 }}
        animate={{ 
          opacity: isOpen ? 1 : 0, 
          x: isOpen ? 0 : -300 
        }}
        transition={{ duration: 0.3, type: "spring", stiffness: 100 }}
        className={`fixed top-20 left-6 z-40 md:hidden ${
          isOpen ? "pointer-events-auto" : "pointer-events-none"
        }`}
      >
        <div className="glass rounded-2xl p-4 border border-white/20 backdrop-blur-md min-w-48">
          <ul className="space-y-2">
            {navItems.map((item, index) => (
              <motion.li
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ 
                  opacity: isOpen ? 1 : 0, 
                  x: isOpen ? 0 : -20 
                }}
                transition={{ 
                  duration: 0.3, 
                  delay: isOpen ? index * 0.1 : 0 
                }}
              >
                <button
                  onClick={() => scrollToSection(item.id)}
                  className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 ${
                    activeSection === item.id
                      ? `bg-white/20 ${
                          isDarkMode 
                            ? (isOnLightSection ? '!text-white' : '!text-gray-900')
                            : (isOnLightSection ? '!text-gray-900' : '!text-white')
                        }`
                      : `${
                          isDarkMode
                            ? (isOnLightSection ? '!text-white/70 hover:!text-white' : '!text-gray-700 hover:!text-gray-900')
                            : (isOnLightSection ? '!text-gray-700 hover:!text-gray-900' : '!text-white/70 hover:!text-white')
                        } hover:bg-white/10`
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </button>
              </motion.li>
            ))}
          </ul>
        </div>
      </motion.div>

      {/* Mobile Menu Backdrop */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setIsOpen(false)}
          className="fixed inset-0 bg-black/20 z-30 md:hidden"
        />
      )}
    </>
  );
};

export default Navigation;