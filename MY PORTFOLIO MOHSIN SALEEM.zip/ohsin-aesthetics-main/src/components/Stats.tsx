import { motion, useInView } from "framer-motion";
import { useRef, useEffect, useState } from "react";
import { GraduationCap, BookOpen, Lightbulb, Users } from "lucide-react";

const Stats = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const [counters, setCounters] = useState({
    years: 0,
    topics: 0,
    projects: 0,
    collaborations: 0
  });

  const finalStats = {
    years: 2,
    topics: 1,
    projects: 3,
    collaborations: 1
  };

  const statsData = [
    {
      icon: GraduationCap,
      label: "Years of Study",
      value: counters.years,
      suffix: "+",
      color: "from-blue-400 to-blue-600",
      description: "Dedicated pharmaceutical education"
    },
    {
      icon: BookOpen,
      label: "Research Topics",
      value: counters.topics,
      suffix: "+",
      color: "from-purple-400 to-purple-600",
      description: "Areas explored in AI & Pharmacy"
    },
    {
      icon: Lightbulb,
      label: "Projects Initiated",
      value: counters.projects,
      suffix: "+",
      color: "from-green-400 to-green-600",
      description: "Innovative solutions developed"
    },
    {
      icon: Users,
      label: "Collaborations",
      value: counters.collaborations,
      suffix: "+",
      color: "from-orange-400 to-orange-600",
      description: "Academic and industry partnerships"
    }
  ];

  useEffect(() => {
    if (isInView) {
      const duration = 2000; // 2 seconds
      const steps = 60; // 60 steps for smooth animation
      const interval = duration / steps;

      let currentStep = 0;
      const timer = setInterval(() => {
        currentStep++;
        const progress = currentStep / steps;
        
        setCounters({
          years: Math.round(progress * finalStats.years),
          topics: Math.round(progress * finalStats.topics),
          projects: Math.round(progress * finalStats.projects),
          collaborations: Math.round(progress * finalStats.collaborations)
        });

        if (currentStep >= steps) {
          clearInterval(timer);
          setCounters(finalStats); // Ensure final values are exact
        }
      }, interval);

      return () => clearInterval(timer);
    }
  }, [isInView]);

  return (
    <section className="py-20 bg-background relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/20 via-secondary/20 to-accent/20"></div>
        <motion.div
          className="absolute inset-0"
          animate={{
            backgroundImage: [
              "radial-gradient(circle at 20% 20%, hsl(var(--primary)) 0%, transparent 50%)",
              "radial-gradient(circle at 80% 80%, hsl(var(--secondary)) 0%, transparent 50%)",
              "radial-gradient(circle at 40% 60%, hsl(var(--accent)) 0%, transparent 50%)"
            ]
          }}
          transition={{ duration: 8, repeat: Infinity, repeatType: "reverse" }}
        />
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-6xl mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-16">
            <motion.h2 
              className="text-4xl md:text-5xl font-bold text-gradient mb-4"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              Academic Journey
            </motion.h2>
            <motion.p 
              className="text-xl text-muted-foreground max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Numbers that tell the story of my dedication to pharmaceutical innovation
            </motion.p>
          </div>

          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {statsData.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ 
                  duration: 0.6, 
                  delay: index * 0.1,
                  type: "spring",
                  stiffness: 100
                }}
                viewport={{ once: true }}
                className="group"
              >
                <div className="glass rounded-2xl p-8 text-center hover-lift relative overflow-hidden">
                  {/* Background Gradient Effect */}
                  <motion.div
                    className={`absolute inset-0 bg-gradient-to-r ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`}
                  />
                  
                  {/* Icon */}
                  <motion.div 
                    className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-r ${stat.color} p-4 text-white`}
                    whileHover={{ 
                      scale: 1.1,
                      rotate: [0, -5, 5, 0],
                      transition: { duration: 0.5 }
                    }}
                  >
                    <stat.icon className="w-full h-full" />
                  </motion.div>

                  {/* Counter */}
                  <motion.div 
                    className="mb-4"
                    initial={{ scale: 0.5, opacity: 0 }}
                    whileInView={{ scale: 1, opacity: 1 }}
                    transition={{ duration: 0.5, delay: index * 0.1 + 0.3 }}
                    viewport={{ once: true }}
                  >
                    <span className="text-4xl md:text-5xl font-bold text-gradient">
                      {stat.value}{stat.suffix}
                    </span>
                  </motion.div>

                  {/* Label */}
                  <h3 className="text-lg font-bold text-foreground mb-2 group-hover:text-primary transition-colors">
                    {stat.label}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {stat.description}
                  </p>

                  {/* Bottom Accent */}
                  <motion.div
                    className={`absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r ${stat.color} origin-center scale-x-0 group-hover:scale-x-100 transition-transform duration-300`}
                  />
                </div>
              </motion.div>
            ))}
          </div>

          {/* Progress Indicators */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            viewport={{ once: true }}
            className="text-center mt-16"
          >
            <div className="glass p-8 rounded-2xl max-w-4xl mx-auto">
              <h3 className="text-2xl font-bold text-gradient mb-6">Current Focus Areas</h3>
              <div className="grid md:grid-cols-2 gap-6 text-left">
                <div>
                  <h4 className="font-semibold text-foreground mb-2 flex items-center">
                    <div className="w-3 h-3 bg-primary rounded-full mr-3"></div>
                    AI in Drug Discovery
                  </h4>
                  <p className="text-muted-foreground text-sm">
                    Exploring machine learning applications in pharmaceutical research
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-2 flex items-center">
                    <div className="w-3 h-3 bg-secondary rounded-full mr-3"></div>
                    Pharmacokinetics Modeling
                  </h4>
                  <p className="text-muted-foreground text-sm">
                    Developing predictive models for drug absorption and distribution
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-2 flex items-center">
                    <div className="w-3 h-3 bg-accent rounded-full mr-3"></div>
                    Personalized Medicine
                  </h4>
                  <p className="text-muted-foreground text-sm">
                    AI-driven approaches to individualized treatment plans
                  </p>
                </div>
                <div>
                  <h4 className="font-semibold text-foreground mb-2 flex items-center">
                    <div className="w-3 h-3 bg-primary-light rounded-full mr-3"></div>
                    Digital Health Solutions
                  </h4>
                  <p className="text-muted-foreground text-sm">
                    Integrating technology with traditional pharmacy practice
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Stats;