import { motion } from "framer-motion";
import AnimatedStat from "./AnimatedStats";

const About = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-6xl mx-auto"
        >
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Photo Side */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              viewport={{ once: true }}
              className="flex justify-center lg:justify-start"
            >
              <div className="relative group">
                <div className="absolute -inset-4 bg-gradient-primary rounded-2xl blur opacity-30 group-hover:opacity-50 transition-opacity duration-300"></div>
                <motion.img
                  src="/lovable-uploads/97d9b4d2-cb97-47f9-ac97-e0101d9f2d75.png"
                  alt="Mohsin Saleem"
                  className="relative w-80 h-80 object-cover rounded-2xl shadow-strong hover-lift"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }}
                />
                {/* Floating Elements */}
                <motion.div
                  className="absolute -top-6 -right-6 w-20 h-20 bg-primary/20 rounded-full glass"
                  animate={{ y: [-10, 10, -10] }}
                  transition={{ duration: 4, repeat: Infinity }}
                />
                <motion.div
                  className="absolute -bottom-4 -left-4 w-16 h-16 bg-secondary/20 rounded-full glass"
                  animate={{ y: [10, -10, 10] }}
                  transition={{ duration: 3, repeat: Infinity, delay: 1 }}
                />
              </div>
            </motion.div>

            {/* Content Side */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
              className="space-y-6"
            >
              <div>
                <motion.h2 
                  className="text-4xl md:text-5xl font-bold text-gradient mb-4"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.6 }}
                  viewport={{ once: true }}
                >
                  About Me
                </motion.h2>
                <motion.div 
                  className="w-20 h-1 bg-gradient-primary rounded"
                  initial={{ width: 0 }}
                  whileInView={{ width: 80 }}
                  transition={{ duration: 0.8, delay: 0.8 }}
                  viewport={{ once: true }}
                />
              </div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 1 }}
                viewport={{ once: true }}
                className="space-y-4 text-lg text-muted-foreground leading-relaxed"
              >
                <p>
                  I'm a passionate <span className="text-primary font-semibold">Pharm.D student</span> dedicated to bridging 
                  the gap between traditional pharmacy practice and cutting-edge artificial intelligence technologies.
                </p>
                
                <p>
                  My research focuses on exploring how <span className="text-secondary font-semibold">AI can revolutionize 
                  pharmacology</span>, from drug discovery and development to personalized medicine and patient care optimization.
                </p>
                
                <p>
                  Through my academic journey and research endeavors, I'm committed to contributing to the future of 
                  healthcare by leveraging <span className="text-accent font-semibold">innovative AI solutions</span> that 
                  can enhance pharmaceutical outcomes and improve patient lives.
                </p>
              </motion.div>

              {/* Achievement Stats */}
              <div className="grid grid-cols-2 gap-6 mt-8">
                <AnimatedStat
                  value={2}
                  suffix="+"
                  label="Years of Study"
                  duration={1.5}
                />
                <AnimatedStat
                  value={3}
                  suffix="+"
                  label="Research Areas"
                  duration={2}
                />
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;