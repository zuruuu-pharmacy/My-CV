import { motion, useInView } from 'framer-motion';
import { useEffect, useState, useRef } from 'react';

interface AnimatedStatProps {
  value: number;
  suffix?: string;
  label: string;
  duration?: number;
  className?: string;
}

const AnimatedStat = ({ value, suffix = "", label, duration = 2, className = "" }: AnimatedStatProps) => {
  const [displayValue, setDisplayValue] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      const startTime = Date.now();
      const startValue = 0;
      const endValue = value;
      
      const updateValue = () => {
        const now = Date.now();
        const elapsed = (now - startTime) / 1000;
        const progress = Math.min(elapsed / duration, 1);
        
        // Easing function for smooth animation
        const easeOutQuart = 1 - Math.pow(1 - progress, 4);
        const currentValue = startValue + (endValue - startValue) * easeOutQuart;
        
        setDisplayValue(Math.floor(currentValue));
        
        if (progress < 1) {
          requestAnimationFrame(updateValue);
        } else {
          setDisplayValue(endValue);
        }
      };
      
      updateValue();
    }
  }, [isInView, value, duration]);

  return (
    <motion.div
      ref={ref}
      className={`text-center p-6 glass rounded-xl hover-lift ${className}`}
      initial={{ opacity: 0, y: 20, scale: 0.9 }}
      whileInView={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ duration: 0.6, delay: 0.2 }}
      viewport={{ once: true }}
      whileHover={{ 
        scale: 1.05,
        boxShadow: "0 20px 40px hsla(var(--primary), 0.2)"
      }}
    >
      <motion.div 
        className="text-4xl font-bold text-primary mb-2"
        key={displayValue}
        initial={{ scale: 1.2 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.3 }}
      >
        {displayValue}{suffix}
      </motion.div>
      <div className="text-sm text-muted-foreground font-medium">{label}</div>
      
      {/* Animated underline */}
      <motion.div
        className="w-0 h-0.5 bg-gradient-primary mx-auto mt-2"
        animate={{ width: isInView ? "60%" : 0 }}
        transition={{ duration: 1, delay: 0.5 }}
      />
    </motion.div>
  );
};

export default AnimatedStat;