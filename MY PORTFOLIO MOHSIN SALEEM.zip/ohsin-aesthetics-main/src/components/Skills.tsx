import { motion } from "framer-motion";
import { Brain, Cpu, Database, Code, Microscope, FlaskConical } from "lucide-react";

const Skills = () => {
  const skills = [
    {
      icon: Brain,
      name: "Pharmacology",
      description: "Drug mechanisms, pharmacokinetics, and therapeutic applications",
      progress: 85,
    },
    {
      icon: Cpu,
      name: "AI in Pharmacy",
      description: "Machine learning applications in drug discovery and patient care",
      progress: 75,
    },
  ];

  const techStack = [
    { name: "PowerPoint", icon: "📊", level: 85 },
    { name: "MS Word", icon: "📝", level: 90 },
    { name: "Canva", icon: "🎨", level: 80 },
    { name: "App Development", icon: "📱", level: 75 },
    { name: "Blender", icon: "🎭", level: 70 },
    { name: "AI Tools", icon: "🤖", level: 85 },
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-6xl mx-auto"
        >
          {/* Header */}
          <div className="text-center mb-16">
            <motion.h2 
              className="text-4xl md:text-5xl font-bold text-gradient mb-4"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              viewport={{ once: true }}
            >
              Skills & Expertise
            </motion.h2>
            <motion.p 
              className="text-xl text-muted-foreground max-w-2xl mx-auto"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              viewport={{ once: true }}
            >
              Bridging traditional pharmacy knowledge with cutting-edge AI technologies
            </motion.p>
          </div>

          {/* Main Skills */}
          <div className="grid md:grid-cols-2 gap-8 mb-16">
            {skills.map((skill, index) => (
              <motion.div
                key={skill.name}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.2 }}
                viewport={{ once: true }}
                className="glass p-8 rounded-2xl hover-lift group"
              >
                <div className="flex items-start space-x-4">
                  <div className="p-3 bg-gradient-primary rounded-xl text-white group-hover:scale-110 transition-transform duration-300">
                    <skill.icon className="w-8 h-8" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-foreground mb-2">{skill.name}</h3>
                    <p className="text-muted-foreground mb-4">{skill.description}</p>
                    
                    {/* Progress Bar */}
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Proficiency</span>
                        <span className="text-primary font-semibold">{skill.progress}%</span>
                      </div>
                      <div className="w-full bg-border rounded-full h-3">
                        <motion.div 
                          className="bg-gradient-primary h-3 rounded-full"
                          initial={{ width: 0 }}
                          whileInView={{ width: `${skill.progress}%` }}
                          transition={{ duration: 1.5, delay: 0.5 }}
                          viewport={{ once: true }}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Tech Stack */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <h3 className="text-3xl font-bold text-gradient mb-8">Tech Stack</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
              {techStack.map((tech, index) => (
                <motion.div
                  key={tech.name}
                  initial={{ opacity: 0, scale: 0.8 }}
                  whileInView={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="glass p-4 rounded-xl hover-scale group cursor-pointer"
                >
                  <div className="text-4xl mb-2 group-hover:animate-bounce">{tech.icon}</div>
                  <h4 className="font-semibold text-foreground">{tech.name}</h4>
                  <div className="w-full bg-border rounded-full h-2 mt-2">
                    <motion.div 
                      className="bg-gradient-primary h-2 rounded-full"
                      initial={{ width: 0 }}
                      whileInView={{ width: `${tech.level}%` }}
                      transition={{ duration: 1, delay: index * 0.1 + 0.5 }}
                      viewport={{ once: true }}
                    />
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;